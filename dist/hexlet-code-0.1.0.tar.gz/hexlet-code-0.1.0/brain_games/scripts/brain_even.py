#!usr/bin/env python
from brain_games import even_or_not


def main():
    even_or_not.even_or_not()


if __name__ == "__main__":
    main()
