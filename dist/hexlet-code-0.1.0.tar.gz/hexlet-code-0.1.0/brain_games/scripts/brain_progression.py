#!usr/bin/env python
from brain_games import progression_game


def main():
    progression_game.progression_game()


if __name__ == "__main__":
    main()
