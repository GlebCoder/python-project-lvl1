#!usr/bin/env python
from brain_games import calc


def main():
    calc.calc()


if __name__ == "__main__":
    main()
